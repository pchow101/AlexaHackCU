import six

if six.PY2:
    collect_ignore = ['wolframalpha/pmxbot.py']
