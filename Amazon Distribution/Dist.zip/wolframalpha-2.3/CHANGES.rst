2.3
===

Moved hosting to Github.

2.2
===

Add support for images (img attribute on Atom).

2.0
===

``pmxbot`` plugin now requires that the "Wolfram|Alpha API key"
config parameter be supplied. The hard-coded key has been
removed and will be de-activated. Users must register for their
own key at the `Wolfram|Alpha developer web site
<https://developer.wolframalpha.com>`_.

Additionally, the tests now no longer bundle a hard-coded API
key. Instead, to run the tests, one must supply a
``WOLFRAMALPHA_API_KEY`` environment variable.

1.4
===

Add pmxbot module and plugin, superseding pmxbot-wolframalpha package.

1.3
===

Moved hosting to Github.
