# AlexaHackCU

## Before you run the app

pip install -r requirements.txt
